# Divesh S
**Coimbatore, Tamil Nadu, India** | **+91 6382184458** | **diveshs0801@gmail.com**  
[LinkedIn](https://linkedin.com/in/divesh-s-57bbaa8236) | [GitHub](https://github.com/diveshs0801)

---

## PROFESSIONAL SUMMARY
Software Engineer with 1+ year of professional experience designing and building high-concurrency backend services, distributed systems, and full-stack web platforms using **NestJS**, **Next.js 16 (React 19)**, **Go (Golang)**, and **Microservices Architecture**. Proven track record architecting the core distributed backend for **TaxiBy** (enterprise ride-hailing & fleet mobility platform), slashing Google Maps API costs by **70–80%** via an intelligent Redis proxy, and engineering sub-second driver dispatch & tracking using **Uber's H3 Hexagonal Spatial Index** and **WebSockets**. Experienced in event-driven distributed architectures with **Apache Kafka**, **RabbitMQ**, **Docker**, and custom **API Gateways**.

---

## TECHNICAL SKILLS
- **Programming Languages:** TypeScript, JavaScript (ES6+), Go (Golang), SQL
- **Backend & Frameworks:** NestJS, Node.js, Express.js, RESTful APIs, WebSockets (Socket.IO), gRPC
- **Frontend Technologies:** Next.js 16 (App Router, SSR), React 19, HTML5, CSS3, Tailwind CSS, Zustand, Redux, TanStack Query
- **Distributed Systems & Queues:** Microservices Architecture, Apache Kafka, RabbitMQ, BullMQ, Redis (Pub/Sub, Caching, H3 Geospatial), API Gateways (KrakenD)
- **Databases & ORMs:** PostgreSQL, MySQL, MongoDB, Prisma ORM, TypeORM
- **Geospatial & Algorithms:** Uber H3 Spatial Index, Haversine Formula, Geofencing
- **Cloud, Security & Tools:** Docker, Docker Compose, AWS (EC2, S3), Cashfree Payouts & Webhooks, Git, GitHub, Linux, Postman

---

## PROFESSIONAL EXPERIENCE

### **Webnox Technologies** | Coimbatore, India
**Software Engineer** | *August 2025 – September 2026*
- Architected the high-concurrency backend for **TaxiBy** (enterprise ride-hailing & fleet mobility platform) in **NestJS** microservices (`core`, `tracking`, `notifications`), managing real-time driver telemetry, dynamic surge pricing, and automated dispatch.
- Engineered a sub-second driver dispatch & tracking engine using **Uber’s H3 Hexagonal Spatial Index (Res 7)** and **Redis Sets**, replacing expensive database polygonal queries with $O(1)$ lookups (<2ms latency).
- Engineered real-time driver GPS telemetry streaming via **WebSockets** and **Redis**, implementing distance-threshold throttling and debouncing to eliminate redundant location pings and reduce network payload by **~75%**.
- Slashed third-party **Google Maps API overhead by 70–80%** (saving ₹25k–₹35k/month) by designing a centralized backend Directions proxy with coordinate-rounding Redis cache and building an offline pure-TypeScript pricing engine.
- Built an **immutable double-entry wallet ledger** using **PostgreSQL (Prisma)** transactions and idempotency keys, eliminating race conditions and double-crediting during rider payments and driver payouts.
- Integrated automated driver wallet withdrawals and instant bank disbursals via **Cashfree Payouts API** with secure webhook verification, automating end-of-day driver settlement with zero manual intervention.
- Spearheaded development of 3 enterprise dashboards (Superadmin, Employee Call-Center CRM, Rider Web App) in **Next.js 16 (React 19)**, **Tailwind CSS**, **Zustand**, and **Socket.IO** with Redis Pub/Sub adapter for live telematics.

---

## PROJECTS / DISTRIBUTED SYSTEMS

### **Enterprise Multi-Tenant ERP Microservices (EFS)** | *Go (Golang), Apache Kafka, gRPC, PostgreSQL, Redis, KrakenD, Docker*
- Architected an enterprise multi-tenant ERP platform spanning 11 microservices in **Go (Golang)**, **Apache Kafka**, **gRPC**, and **PostgreSQL**, processing work orders, procurement, and real-time fleet dispatching across isolated tenant domains.
- Implemented the **Transactional Outbox Pattern** in Go with background event relay and exponential backoff retry workers, eliminating dual-write distributed transaction failures and guaranteeing at-least-once delivery across 15+ Kafka domain topics.
- Engineered an in-memory GPS dispatch & route optimization engine in Go using the **Haversine geodesic formula** and Nearest-Neighbor heuristics with time-window priority, slashing route calculation latency from ~650ms (external APIs) to **<12ms**.
- Designed a high-throughput API Gateway layer (**KrakenD**) with stateless JWT authentication, CORS termination, and tenant context injection (`X-Tenant-ID`), handling **8,000+ req/sec** with sub-5ms proxy overhead.
- Built an automated Field Service & Billing pipeline via **gRPC** and Kafka choreography, auto-generating digital Field Service Reports (FSR) with S3-compatible pre-signed upload URLs to reduce server media transit bandwidth by **85%**.

---

## EDUCATION
- **Bachelor of Engineering in Computer Science and Engineering** | *CGPA: 7.93 / 10*  
  Sri Shakthi Institute of Engineering and Technology, Coimbatore *(Oct 2021 – Apr 2025)*
- **Higher Secondary Certificate (Class 12)** | *Percentage: 93%*  
  Sai Vidhya Nikethan Matric Higher Secondary School, Alamarai Thottam *(Jun 2020 – Mar 2021)*
- **Secondary School Leaving Certificate (Class 10)** | *Percentage: 93.2%*  
  SRMV Swami Shivananda Higher Secondary School, Periyanaickenpalayam *(May 2018 – May 2019)*
